// 1 - Pacote = Conjunto de Classes
package todo;

// 2 - Bibliotecas = Métodos e Funções Prontos

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;


// 3 - Classe
public class ListasPuro {
    // 3.1 - Atributos = Características
    String url; // guardará o endereço do site alvo
    WebDriver driver; // objeto do Selenium WebDriver

    // 3.2 - Métodos ou Funcionalidades = O que ele sabe fazer
    @Before
    public void inicializar(){
        // Declarando o endereço do site alvo
        url = "https://todo.microsoft.com";

        // Informando o local
        System.setProperty("webdriver.chrome.driver","drivers/chrome/87/chromedriver.exe");

        // Instanciar o objeto Selenium WebDriver como navegador Chrome
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
        driver.manage().window().maximize(); // maximiza a janela do navegador

    }

    @After
    public void finalizar(){
        driver.quit(); // destruir o objeto Selenium WebDriver
    }

    @Test
    public void test1_CriarListaComTresItens() throws InterruptedException {
        driver.get(url);

        // Página de Login
        driver.findElement(By.id("mectrl_headerPicture")).click(); // clica no icone de Sign In/ Log In
        Thread.sleep(3000);
        driver.findElement(By.id("i0116")).sendKeys("cleber2011@hotmail.com"); // preenche/cola o e-mail
        driver.findElement(By.id("idSIButton9")).click(); // clica no botão Próximo
        Thread.sleep(3000);
        //driver.findElement(By.id("msaTileHint")).click(); // seleciona a conta pessoal
        driver.findElement(By.id("i0118")).sendKeys("Iterasys2020"); // preenche/cola a senha
        Thread.sleep(3000);
        driver.findElement(By.id("idSIButton9")).click(); // clica no botão Próximo
        //driver.findElement(By.id("idSIButton9")).click(); // clica no botão Sim
        //Thread.sleep(22000);


        // Página de Tasks - Tarefas
        driver.findElement(By.id("baseAddInput-addList")).click(); // clica no elemento "Nova Lista"
        driver.findElement(By.id("baseAddInput-addList")).clear(); // apaga o texto no elemento
        // driver.findElement(By.id("baseAddInput-addList")).sendKeys("Musicas"); // cola a palavra "Musica"

        // Cria a lista Musica
        driver.findElement(By.id("baseAddInput-addList")).sendKeys(Keys.chord("Musicas")); // soletra a palavra "Musica"
        // implementar o print da tela
        driver.findElement(By.id("baseAddInput-addList")).sendKeys(Keys.ENTER); // pressiona a tecla Enter

        // Adiciona 3 músicas a lista
        driver.findElement(By.id("baseAddInput-addTask")).sendKeys("O Quereres" + Keys.ENTER);
        driver.findElement(By.id("baseAddInput-addTask")).sendKeys("Terra" + Keys.ENTER);
        driver.findElement(By.id("baseAddInput-addTask")).sendKeys("Me Gusta" + Keys.ENTER);
    }

    @Test
    public void test2_AlterarNomeLista() throws InterruptedException {
        driver.get(url);

        // Página de Login
        driver.findElement(By.id("mectrl_headerPicture")).click(); // clica no icone de Sign In/ Log In
        Thread.sleep(1000);
        driver.findElement(By.id("i0116")).sendKeys("cleber2011@hotmail.com"); // preenche/cola o e-mail
        driver.findElement(By.id("idSIButton9")).click(); // clica no botão Próximo
        Thread.sleep(1000);
        //driver.findElement(By.id("msaTileHint")).click(); // seleciona a conta pessoal
        driver.findElement(By.id("i0118")).sendKeys("Iterasys2020"); // preenche/cola a senha
        Thread.sleep(1000);
        driver.findElement(By.id("idSIButton9")).click(); // clica no botão Próximo
        //driver.findElement(By.id("idSIButton9")).click(); // clica no botão Sim
        Thread.sleep(9000);

        // Alterar do nome da Tarefas Musicas para Minhas Musicas
        driver.findElement(By.id("AQMkADAwATY3ZmYAZS05MDg5LTJmMGYtMDACLTAwCgAuAAADJkB9gmA2ikGCm8tUHrsP-wEA5kH7pBzAX0KTvGyAGidaJgAD-AxB2wAAAA==")).click();
        driver.findElement(By.cssSelector("div.toolbarButton-icon")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("span.ms-ContextualMenu-itemText.label-77")).click();
        driver.findElement(By.cssSelector("input.chromeless.editing.tasksToolbar-input")).sendKeys(Keys.chord("Minhas Musicas") + Keys.ENTER);
        Thread.sleep(3000);
    }

    @Test
    public void test3_ExcluirLista() throws InterruptedException {
        driver.get(url);

        // Página de Login
        driver.findElement(By.id("mectrl_headerPicture")).click(); // clica no icone de Sign In/ Log In
        Thread.sleep(3000);
        driver.findElement(By.id("i0116")).sendKeys("cleber2011@hotmail.com"); // preenche/cola o e-mail
        driver.findElement(By.id("idSIButton9")).click(); // clica no botão Próximo
        Thread.sleep(3000);
        //driver.findElement(By.id("msaTileHint")).click(); // seleciona a conta pessoal
        driver.findElement(By.id("i0118")).sendKeys("Iterasys2020"); // preenche/cola a senha
        Thread.sleep(3000);
        driver.findElement(By.id("idSIButton9")).click(); // clica no botão Próximo
        //driver.findElement(By.id("idSIButton9")).click(); // clica no botão Sim
        Thread.sleep(9000);

        // Excluir a Tarefas Minhas Musicas
        driver.findElement(By.id("AQMkADAwATY3ZmYAZS05MDg5LTJmMGYtMDACLTAwCgAuAAADJkB9gmA2ikGCm8tUHrsP-wEA5kH7pBzAX0KTvGyAGidaJgAD-AxB1AAAAA==")).click();
        driver.findElement(By.cssSelector("div.toolbarButton-icon")).click();
        Thread.sleep(1000);
        driver.findElement(By.cssSelector("i.icon.fontIcon.ms-Icon.ms-Icon--Delete.iconSize-24")).click();
        Thread.sleep(1000);
        driver.findElement(By.cssSelector("button.button.red")).click();


    }


}
